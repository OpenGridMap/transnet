CREATE FUNCTION st_count (rast raster, exclude_nodata_value boolean) RETURNS bigint
AS $$
 SELECT _st_count($1, 1, $2, 1) 
$$
