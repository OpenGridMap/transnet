CREATE FUNCTION st_intersects (text, text) RETURNS boolean
AS $$
 SELECT ST_Intersects($1::geometry, $2::geometry);  
$$
