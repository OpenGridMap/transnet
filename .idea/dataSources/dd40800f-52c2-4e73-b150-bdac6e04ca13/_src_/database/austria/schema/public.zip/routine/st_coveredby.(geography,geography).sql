CREATE FUNCTION st_coveredby (geography, geography) RETURNS boolean
AS $$
SELECT $1 && $2 AND _ST_Covers($2, $1)
$$
