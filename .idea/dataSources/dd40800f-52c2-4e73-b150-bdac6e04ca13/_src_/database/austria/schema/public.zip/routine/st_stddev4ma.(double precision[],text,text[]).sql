CREATE FUNCTION st_stddev4ma (matrix double precision[], nodatamode text, VARIADIC args text[]) RETURNS double precision
AS $$
 SELECT stddev(unnest) FROM unnest($1) 
$$
