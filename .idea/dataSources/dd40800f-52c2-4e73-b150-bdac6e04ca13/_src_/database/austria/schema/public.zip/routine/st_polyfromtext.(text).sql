CREATE FUNCTION st_polyfromtext (text) RETURNS geometry
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromText($1)) = 'POLYGON'
	THEN ST_GeomFromText($1)
	ELSE NULL END
	
$$
