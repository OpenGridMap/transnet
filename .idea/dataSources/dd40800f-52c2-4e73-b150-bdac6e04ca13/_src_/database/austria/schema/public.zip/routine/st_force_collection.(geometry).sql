CREATE FUNCTION st_force_collection (geometry) RETURNS geometry
AS $$
 SELECT _postgis_deprecate('ST_Force_Collection', 'ST_ForceCollection', '2.1.0');
    SELECT ST_ForceCollection($1);
  
$$
