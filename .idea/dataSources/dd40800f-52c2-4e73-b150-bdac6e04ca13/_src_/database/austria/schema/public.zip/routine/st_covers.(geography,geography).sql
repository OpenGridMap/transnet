CREATE FUNCTION st_covers (geography, geography) RETURNS boolean
AS $$
SELECT $1 && $2 AND _ST_Covers($1, $2)
$$
