CREATE FUNCTION st_distancesphere (geom1 geometry, geom2 geometry) RETURNS double precision
AS $$
	select st_distance(geography($1),geography($2),false)
	
$$
