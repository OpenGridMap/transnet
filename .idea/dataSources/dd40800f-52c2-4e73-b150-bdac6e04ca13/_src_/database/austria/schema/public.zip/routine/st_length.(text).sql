CREATE FUNCTION st_length (text) RETURNS double precision
AS $$
 SELECT ST_Length($1::geometry);  
$$
