CREATE FUNCTION st_intersects (geography, geography) RETURNS boolean
AS $$
SELECT $1 && $2 AND _ST_Distance($1, $2, 0.0, false) < 0.00001
$$
