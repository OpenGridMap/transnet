CREATE FUNCTION st_multipolygonfromtext (text) RETURNS geometry
AS $$
SELECT ST_MPolyFromText($1)
$$
