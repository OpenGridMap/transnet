CREATE FUNCTION st_astext (text) RETURNS text
AS $$
 SELECT ST_AsText($1::geometry);  
$$
