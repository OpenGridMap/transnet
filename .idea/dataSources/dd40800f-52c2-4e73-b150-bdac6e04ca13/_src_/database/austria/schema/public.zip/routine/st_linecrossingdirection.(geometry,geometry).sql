CREATE FUNCTION st_linecrossingdirection (geom1 geometry, geom2 geometry) RETURNS integer
AS $$
 SELECT CASE WHEN NOT $1 && $2 THEN 0 ELSE _ST_LineCrossingDirection($1,$2) END 
$$
