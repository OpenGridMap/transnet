CREATE FUNCTION st_askml (text) RETURNS text
AS $$
 SELECT _ST_AsKML(2, $1::geometry, 15, null);  
$$
