CREATE FUNCTION st_asgeojson (text) RETURNS text
AS $$
 SELECT _ST_AsGeoJson(1, $1::geometry,15,0);  
$$
