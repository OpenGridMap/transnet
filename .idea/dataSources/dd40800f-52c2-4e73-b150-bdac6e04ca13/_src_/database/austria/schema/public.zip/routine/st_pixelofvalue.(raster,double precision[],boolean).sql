CREATE FUNCTION st_pixelofvalue (rast raster, search double precision[], exclude_nodata_value boolean DEFAULT true, OUT val double precision, OUT x integer, OUT y integer) RETURNS SETOF record
AS $$
 SELECT val, x, y FROM st_pixelofvalue($1, 1, $2, $3) 
$$
