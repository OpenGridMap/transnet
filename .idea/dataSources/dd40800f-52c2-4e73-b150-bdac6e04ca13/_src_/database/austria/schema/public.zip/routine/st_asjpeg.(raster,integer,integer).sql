CREATE FUNCTION st_asjpeg (rast raster, nband integer, quality integer) RETURNS bytea
AS $$
 SELECT st_asjpeg($1, ARRAY[$2], $3) 
$$
