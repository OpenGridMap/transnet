CREATE FUNCTION st_rotatez (geometry, double precision) RETURNS geometry
AS $$
SELECT ST_Rotate($1, $2)
$$
