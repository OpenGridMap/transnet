CREATE FUNCTION geometry_contained_by_raster (geometry, raster) RETURNS boolean
AS $$
select $1 @ $2::geometry
$$
