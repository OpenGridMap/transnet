CREATE FUNCTION st_mapalgebrafct (rast raster, onerastuserfunc regprocedure, VARIADIC args text[]) RETURNS raster
AS $$
 SELECT st_mapalgebrafct($1, 1, NULL, $2, VARIADIC $3) 
$$
