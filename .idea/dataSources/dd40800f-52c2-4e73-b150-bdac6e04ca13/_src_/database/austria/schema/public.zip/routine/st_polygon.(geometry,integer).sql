CREATE FUNCTION st_polygon (geometry, integer) RETURNS geometry
AS $$
 
	SELECT ST_SetSRID(ST_MakePolygon($1), $2)
	
$$
