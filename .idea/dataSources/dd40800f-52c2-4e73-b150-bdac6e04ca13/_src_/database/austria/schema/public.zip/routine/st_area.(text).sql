CREATE FUNCTION st_area (text) RETURNS double precision
AS $$
 SELECT ST_Area($1::geometry);  
$$
