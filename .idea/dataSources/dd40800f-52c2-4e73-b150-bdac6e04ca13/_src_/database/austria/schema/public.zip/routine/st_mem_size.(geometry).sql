CREATE FUNCTION st_mem_size (geometry) RETURNS integer
AS $$
 SELECT _postgis_deprecate('ST_Mem_Size', 'ST_MemSize', '2.2.0');
    SELECT ST_MemSize($1);
  
$$
