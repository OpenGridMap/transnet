CREATE FUNCTION st_intersects (geom geometry, rast raster, nband integer DEFAULT NULL::integer) RETURNS boolean
AS $$
 SELECT $1 && $2::geometry AND _st_intersects($1, $2, $3); 
$$
