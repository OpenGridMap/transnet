CREATE FUNCTION st_polygonfromtext (text, integer) RETURNS geometry
AS $$
SELECT ST_PolyFromText($1, $2)
$$
