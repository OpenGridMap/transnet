CREATE FUNCTION postgis_raster_scripts_installed () RETURNS text
AS $$
 SELECT '2.2.1'::text || ' r' || 14555::text AS version 
$$
