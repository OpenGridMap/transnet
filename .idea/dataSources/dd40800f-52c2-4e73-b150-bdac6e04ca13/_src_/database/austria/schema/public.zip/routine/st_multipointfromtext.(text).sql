CREATE FUNCTION st_multipointfromtext (text) RETURNS geometry
AS $$
SELECT ST_MPointFromText($1)
$$
