CREATE FUNCTION st_geomfromwkb (bytea, integer) RETURNS geometry
AS $$
SELECT ST_SetSRID(ST_GeomFromWKB($1), $2)
$$
