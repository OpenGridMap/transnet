CREATE FUNCTION st_approxquantile (rast raster, quantiles double precision[], OUT quantile double precision, OUT value double precision) RETURNS SETOF record
AS $$
 SELECT _st_quantile($1, 1, TRUE, 0.1, $2) 
$$
