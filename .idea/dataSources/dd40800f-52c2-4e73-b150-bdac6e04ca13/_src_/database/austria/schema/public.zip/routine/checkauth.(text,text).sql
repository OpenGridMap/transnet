CREATE FUNCTION checkauth (text, text) RETURNS integer
AS $$
 SELECT CheckAuth('', $1, $2) 
$$
