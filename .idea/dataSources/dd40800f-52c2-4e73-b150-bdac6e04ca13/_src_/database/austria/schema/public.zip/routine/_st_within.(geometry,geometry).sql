CREATE FUNCTION _st_within (geom1 geometry, geom2 geometry) RETURNS boolean
AS $$
SELECT _ST_Contains($2,$1)
$$
