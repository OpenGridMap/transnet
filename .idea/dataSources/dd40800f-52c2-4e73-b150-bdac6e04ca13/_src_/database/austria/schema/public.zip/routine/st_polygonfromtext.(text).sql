CREATE FUNCTION st_polygonfromtext (text) RETURNS geometry
AS $$
SELECT ST_PolyFromText($1)
$$
