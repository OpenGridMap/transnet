CREATE FUNCTION raster_eq (raster, raster) RETURNS boolean
AS $$
 SELECT raster_hash($1) = raster_hash($2) 
$$
