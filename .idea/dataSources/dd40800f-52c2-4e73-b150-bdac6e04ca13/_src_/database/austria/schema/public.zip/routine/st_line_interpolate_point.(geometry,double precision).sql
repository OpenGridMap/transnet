CREATE FUNCTION st_line_interpolate_point (geometry, double precision) RETURNS geometry
AS $$
 SELECT _postgis_deprecate('ST_Line_Interpolate_Point', 'ST_LineInterpolatePoint', '2.1.0');
    SELECT ST_LineInterpolatePoint($1, $2);
  
$$
