CREATE FUNCTION st_asewkt (text) RETURNS text
AS $$
 SELECT ST_AsEWKT($1::geometry);  
$$
