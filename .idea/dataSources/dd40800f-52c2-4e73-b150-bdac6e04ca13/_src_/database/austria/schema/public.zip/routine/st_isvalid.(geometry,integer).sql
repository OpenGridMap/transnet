CREATE FUNCTION st_isvalid (geometry, integer) RETURNS boolean
AS $$
SELECT (ST_isValidDetail($1, $2)).valid
$$
