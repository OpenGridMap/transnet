CREATE FUNCTION st_multilinestringfromtext (text) RETURNS geometry
AS $$
SELECT ST_MLineFromText($1)
$$
