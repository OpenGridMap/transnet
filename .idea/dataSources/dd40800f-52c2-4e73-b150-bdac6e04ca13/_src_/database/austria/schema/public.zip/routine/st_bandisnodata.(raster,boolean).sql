CREATE FUNCTION st_bandisnodata (rast raster, forcechecking boolean) RETURNS boolean
AS $$
 SELECT st_bandisnodata($1, 1, $2) 
$$
