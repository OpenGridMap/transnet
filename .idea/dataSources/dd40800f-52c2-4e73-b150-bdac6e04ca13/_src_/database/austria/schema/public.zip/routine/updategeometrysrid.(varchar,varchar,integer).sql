CREATE FUNCTION updategeometrysrid (character varying, character varying, integer) RETURNS text
AS $$
DECLARE
	ret  text;
BEGIN
	SELECT UpdateGeometrySRID('','',$1,$2,$3) into ret;
	RETURN ret;
END;
$$
