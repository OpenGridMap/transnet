CREATE FUNCTION st_asjpeg (rast raster, nbands integer[], options text[] DEFAULT NULL::text[]) RETURNS bytea
AS $$
 SELECT st_asjpeg(st_band($1, $2), $3) 
$$
