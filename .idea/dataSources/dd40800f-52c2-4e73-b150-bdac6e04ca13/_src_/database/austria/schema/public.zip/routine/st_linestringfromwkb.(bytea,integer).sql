CREATE FUNCTION st_linestringfromwkb (bytea, integer) RETURNS geometry
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN ST_GeomFromWKB($1, $2)
	ELSE NULL END
	
$$
