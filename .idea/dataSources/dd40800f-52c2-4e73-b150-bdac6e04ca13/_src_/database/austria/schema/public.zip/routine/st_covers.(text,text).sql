CREATE FUNCTION st_covers (text, text) RETURNS boolean
AS $$
 SELECT ST_Covers($1::geometry, $2::geometry);  
$$
