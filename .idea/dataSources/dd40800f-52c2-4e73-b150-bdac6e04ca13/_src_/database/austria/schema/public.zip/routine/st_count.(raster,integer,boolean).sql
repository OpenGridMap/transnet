CREATE FUNCTION st_count (rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true) RETURNS bigint
AS $$
 SELECT _st_count($1, $2, $3, 1) 
$$
