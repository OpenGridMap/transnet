CREATE FUNCTION st_mapalgebrafct (rast raster, band integer, onerastuserfunc regprocedure) RETURNS raster
AS $$
 SELECT st_mapalgebrafct($1, $2, NULL, $3, NULL) 
$$
