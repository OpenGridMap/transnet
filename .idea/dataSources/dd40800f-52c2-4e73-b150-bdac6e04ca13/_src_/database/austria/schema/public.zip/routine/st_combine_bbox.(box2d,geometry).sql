CREATE FUNCTION st_combine_bbox (box2d, geometry) RETURNS box2d
AS $$
 SELECT _postgis_deprecate('ST_Combine_BBox', 'ST_CombineBbox', '2.2.0');
    SELECT ST_CombineBbox($1,$2);
  
$$
