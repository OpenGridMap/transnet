CREATE FUNCTION geometry_raster_overlap (geometry, raster) RETURNS boolean
AS $$
select $1 && $2::geometry
$$
