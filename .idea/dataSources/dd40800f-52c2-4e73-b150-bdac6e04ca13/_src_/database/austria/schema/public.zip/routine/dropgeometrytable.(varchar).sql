CREATE FUNCTION dropgeometrytable (table_name character varying) RETURNS text
AS $$
 SELECT DropGeometryTable('','',$1) 
$$
