CREATE FUNCTION st_linefromtext (text, integer) RETURNS geometry
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'LINESTRING'
	THEN ST_GeomFromText($1,$2)
	ELSE NULL END
	
$$
