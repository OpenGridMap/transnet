CREATE FUNCTION raster_contain (raster, raster) RETURNS boolean
AS $$
select $1::geometry ~ $2::geometry
$$
