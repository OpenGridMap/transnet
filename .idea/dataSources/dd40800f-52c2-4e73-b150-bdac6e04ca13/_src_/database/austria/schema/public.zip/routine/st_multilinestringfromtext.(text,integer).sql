CREATE FUNCTION st_multilinestringfromtext (text, integer) RETURNS geometry
AS $$
SELECT ST_MLineFromText($1, $2)
$$
