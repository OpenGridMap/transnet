CREATE FUNCTION st_polyfromtext (text, integer) RETURNS geometry
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'POLYGON'
	THEN ST_GeomFromText($1, $2)
	ELSE NULL END
	
$$
