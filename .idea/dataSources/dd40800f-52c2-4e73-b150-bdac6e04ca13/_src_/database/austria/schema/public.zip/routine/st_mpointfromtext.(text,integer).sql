CREATE FUNCTION st_mpointfromtext (text, integer) RETURNS geometry
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'MULTIPOINT'
	THEN ST_GeomFromText($1, $2)
	ELSE NULL END
	
$$
