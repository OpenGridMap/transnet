CREATE FUNCTION st_setvalue (rast raster, x integer, y integer, newvalue double precision) RETURNS raster
AS $$
 SELECT st_setvalue($1, 1, $2, $3, $4) 
$$
