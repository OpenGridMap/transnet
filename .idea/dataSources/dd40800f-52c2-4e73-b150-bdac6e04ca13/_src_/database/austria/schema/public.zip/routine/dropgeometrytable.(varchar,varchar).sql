CREATE FUNCTION dropgeometrytable (schema_name character varying, table_name character varying) RETURNS text
AS $$
 SELECT DropGeometryTable('',$1,$2) 
$$
