CREATE FUNCTION _st_bestsrid (geography) RETURNS integer
AS $$
SELECT _ST_BestSRID($1,$1)
$$
